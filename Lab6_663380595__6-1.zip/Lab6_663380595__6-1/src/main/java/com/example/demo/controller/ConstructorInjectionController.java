package com.example.demo.controller;

import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/constructor")
public class ConstructorInjectionController {

    private final CustomerService customerService;


    public ConstructorInjectionController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping("/{id}")
    public String getCustomerById(@PathVariable Long id) {
        Customer cust = customerService.getCustomerById(id);
        return "Constructor Injection: Id:" + cust.getId() + ", Name: " + cust.getName();
    }
    
    @GetMapping("/customer/{id}/{name}")
    public String getCustomerByIdAndName(@PathVariable Long id, @PathVariable String name) {
        Customer cust = new Customer(id, name);
        return "Constructor Injection: Id:" + cust.getId() + ", Name: " + cust.getName();
    }

    @GetMapping("/customerlist")
    public List<Customer> getCustomerList() {
        return customerService.getCustomerList();
    }
}
